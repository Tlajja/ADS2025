7. ADT – Stekas (L)

Programa įgyvendina steko funkcijas.

initStack - Inicializuoja steką
Push - įdeda reikšmę ant steko viršaus
Pop - išima viršutinę steko reikšmę
Peek - pažiūri viršutinę steko reikšmę ir jos neištrina
isEmpty - pažiūri ar stekas tuščias
freeStack - atlaisvina atmintį
